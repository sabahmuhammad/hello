﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;


namespace MIS333KProjectGroup28.Models
{
    public class Reservation
    {
        //TODO: Need to have reservations start from 1000
        [Display(Name = "Reservation ID")]
        public Int32 ReservationID { get; set; }

        /*[Required(ErrorMessage = "Primary Traveler is required")]
        [Display(PrimaryTraveler = "Primary Traveler")]
        public String PrimaryTraveler { get; set; }*/

        [Required(ErrorMessage = "Date and Time are required")]
        [DataType(DataType.DateTime, ErrorMessage = "Enter a valid date and time")]
        [Display(Name = " Reservation Date and Time")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime ReservationDateTime { get; set; }

        //Navigational Properties
        public virtual AppUser Customer { get; set; }
        public virtual List<ReservationDetail> ReservationDetails { get; set; }




    }
}
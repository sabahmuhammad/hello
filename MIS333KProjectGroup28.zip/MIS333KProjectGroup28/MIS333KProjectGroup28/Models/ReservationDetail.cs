﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MIS333KProjectGroup28.Models
{
    public class ReservationDetail
    {
        [Display(Name = "Reservation Detail ID")]
        public Int32 ReservationDetailID { get; set; }

        [Required(ErrorMessage = "Seat is required")]
        [Display(Name = "Seat")]
        public String Seat { get; set; }

        [DataType(DataType.Currency, ErrorMessage = "Enter a valid price")]
        [Display(Name = "Final Ticket Price")]
        public String FinalTicketPrice { get; set; } 

        [Display(Name = "Lap Child")]
        public bool LapChild { get; set; }

        //navigational properties
        public virtual AppUser Customer { get; set; }
        public virtual Reservation Reservations { get; set; }
        public virtual Flight Flights { get; set; }
    }
}
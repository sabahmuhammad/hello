﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MIS333KProjectGroup28.Models
{
    public class Flight
    {
        [Display(Name = "Flight ID")]
        public Int32 FlightID { get; set; }

        [Required(ErrorMessage = "Flight Number is required.")]
        [Display(Name = "Flight Number")]
        public Int32 FlightNumber { get; set; }

        [Required(ErrorMessage = "City Symbol is required")]
        [Display(Name = "City Symbol")]
        public String CitySymbol { get; set; }

        [Required(ErrorMessage = "City Name is required")]
        [Display(Name = "City Name")]
        public String CityName { get; set; }

        [Required(ErrorMessage = "State is required")]
        [Display(Name = "State")]
        public String State { get; set; }

        [Required(ErrorMessage = "Date and Time are required")]
        [DataType(DataType.DateTime, ErrorMessage = "Enter a valid date and time")]
        [Display(Name = " Flight Date and Time")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime FlightDateTime { get; set; }

        [Required(ErrorMessage = "Day is required")]
        [Display(Name = "Day")]
        public DayOfWeek DayOfWeek { get; set; } 

        [Required(ErrorMessage = "Base price is required")]
        [DataType(DataType.Currency, ErrorMessage = "Enter a valid price")]
        [Display(Name = "Base Price")]
        public String BasePrice { get; set; }

        [Required(ErrorMessage = "Seat is required")]
        [Display(Name = "Seat")]
        public String Seat { get; set; }

        public virtual List<ReservationDetail> ReservationDetails { get; set; }

         

        



        
        




    }
}